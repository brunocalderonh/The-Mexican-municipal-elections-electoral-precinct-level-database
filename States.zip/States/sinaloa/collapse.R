# Clear the environment
rm(list = ls())

# Load necessary libraries
library(readxl)
library(writexl)
library(dplyr)
library(xtable)
library(openxlsx)

# Set working directory
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/")

# Read the Excel file
db <- read_excel("sinaloa/sinaloa_FINAL_draft.xlsx")

# Collapse the database
db <- db %>%
  group_by(uniqueid, year, state, mun) %>%
  summarise(
    incumbent_party_magar = first(incumbent_party_magar),
    incumbent_candidate_magar = first(incumbent_candidate_magar),
    incumbent_vote = first(incumbent_vote),
    # researched_incumbent = first(researched_incumbent),
    # source_researched_incumbent = first(source_researched_incumbent),
    incumbent_party_JL = first(incumbent_party_JL),
    incumbent_candidate_JL = first(incumbent_candidate_JL),
    incumbent_party_Horacio = first(incumbent_party_Horacio),
    incumbent_party_inafed = first(incumbent_party_inafed),
    incumbent_candidate_inafed = first(incumbent_candidate_inafed),
    # state_year = first(state_year),
    # state_incumbent = first(state_incumbent)
  )

#State values

db <- db %>%
  mutate(state_year = case_when(
    year %in% c(2004,2007) ~ 2004,
    year %in% c(2010,2013) ~ 2010,
    year %in% c(2016,2018) ~ 2016,
    TRUE ~ NA_integer_
  ),
  researched_incumbent = NA,  # Create empty variable state_incumbent
  source_researched_incumbent = NA,  # Create empty variable state_candidate
  PRI_vote = NA,
  PRI_vote_party_component = NA,
  ) %>%
  mutate(state_incumbent_party = case_when(
    state_year %in% 2004 ~ "PRI",
    state_year %in% 2010 ~ "PRI",
    state_year %in% 2016 ~ "PAN",
  )) %>%
  mutate(state_incumbent_candidate = case_when(
    state_year %in% 2004 ~ "Juan Sigfrido Millán Lizárraga",
    state_year %in% 2010 ~ "Jesús Alberto Aguilar Padilla",
    state_year %in% 2016 ~ "Mario López Valdez",
  ))  %>%
  select(uniqueid, year, state, mun, incumbent_party_magar,incumbent_candidate_magar,incumbent_vote,researched_incumbent,source_researched_incumbent,incumbent_party_JL,incumbent_candidate_JL,incumbent_party_Horacio,incumbent_party_inafed,incumbent_candidate_inafed,state_year,state_incumbent_party,state_incumbent_candidate,PRI_vote,PRI_vote_party_component)




write_xlsx(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/sinaloa/sinaloa_collapsed.xlsx")

# 
# # Write to CSV to check for issues
# write.csv(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/sinaloa/sinaloa_collapsed.csv", row.names = FALSE)
# 
# # Write to Excel using openxlsx
# write.xlsx(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/sinaloa/sinaloa_collapsed1.xlsx")