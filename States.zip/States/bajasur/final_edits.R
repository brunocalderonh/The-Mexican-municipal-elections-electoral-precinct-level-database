# Clear the environment
rm(list = ls())

# Load necessary libraries
library(readxl)
library(dplyr)

# Set working directory
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/")

# Read the Excel files
db <- read.csv("bajasur/bajasur_FINALV.csv")

assign_votes <- function(data) {
  
  # Initialize columns if they don't exist
  if (!"incumbent_vote" %in% colnames(data)) {
    data <- data %>%
      mutate(incumbent_vote = NA,
             party_component = NA)
  }
  
  # Loop through each row of the data with missing incumbent_vote
  for (I in which(is.na(data$incumbent_vote))) {
    
    # Process rows with a string value in incumbent_party_inafed
    if (!is.na(data$incumbent_party_inafed[I]) && data$incumbent_party_inafed[I] != "") {
      incumbent_party <- data$incumbent_party_inafed[I]
      
      # Reset incumbent_vote and party_component for these rows
      data$incumbent_vote[I] <- NA
      data$party_component[I] <- NA
      
      # Check if it is a coalition
      if (str_detect(incumbent_party, "_")) {
        parties <- unlist(str_split(incumbent_party, "_"))
        
        # Check if any individual party within the coalition is present in other columns
        individual_party_found <- FALSE
        for (party in parties) {
          party_vars <- names(data)[str_detect(names(data), party)]
          
          for (party_var in party_vars) {
            if (!is.na(data[[party_var]][I]) && data[[party_var]][I] != 0) {
              data$incumbent_vote[I] <- data[[party_var]][I]
              data$party_component[I] <- party_var
              individual_party_found <- TRUE
              break
            }
          }
          if (individual_party_found) break
        }
        
        # Proceed with coalition logic if no individual party is found
        if (!individual_party_found) {
          coalition_vars <- names(data)[sapply(names(data), function(x) all(parties %in% str_split(x, "_")[[1]]))]
          
          for (coalition_var in coalition_vars) {
            if (!is.na(data[[coalition_var]][I]) && data[[coalition_var]][I] != 0) {
              data$incumbent_vote[I] <- data[[coalition_var]][I]
              data$party_component[I] <- coalition_var
              break
            }
          }
        }
      } else {
        # Handle single parties
        party_vars <- names(data)[str_detect(names(data), incumbent_party)]
        
        for (party_var in party_vars) {
          # Ensure PAN is not confused with PANAL
          if (str_detect(party_var, "^PAN$") || (!str_detect(party_var, "PANAL") && str_detect(party_var, "PAN"))) {
            if (!is.na(data[[party_var]][I]) && data[[party_var]][I] != 0) {
              data$incumbent_vote[I] <- data[[party_var]][I]
              data$party_component[I] <- party_var
              break
            }
          } else if (!str_detect(party_var, "PAN") && !str_detect(party_var, "PANAL")) {
            if (!is.na(data[[party_var]][I]) && data[[party_var]][I] != 0) {
              data$incumbent_vote[I] <- data[[party_var]][I]
              data$party_component[I] <- party_var
              break
            }
          }
        }
        
        # If no single party found, check coalitions containing the single party
        if (is.na(data$incumbent_vote[I])) {
          coalition_vars <- names(data)[sapply(names(data), function(x) incumbent_party %in% str_split(x, "_")[[1]])]
          
          for (coalition_var in coalition_vars) {
            if (!is.na(data[[coalition_var]][I]) && data[[coalition_var]][I] != 0) {
              data$incumbent_vote[I] <- data[[coalition_var]][I]
              data$party_component[I] <- coalition_var
              break
            }
          }
        }
      }
    }
  }
  
  return(data)
}

db <- assign_votes(db)

write.csv(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/bajasur/bajasur_FINALV.csv")



