# Clear the environment
rm(list = ls())

# Load necessary libraries
library(readxl)
library(writexl)
library(dplyr)
library(xtable)
# Set working directory
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/")

# Read the Excel file
db <- read_excel("bajasur/bajasur_FINAL_draft.xlsx")

# Collapse the database
db <- db %>%
  group_by(uniqueid, year, state, mun) %>%
  summarise(
    incumbent_party_magar = first(incumbent_party_magar),
    incumbent_candidate_magar = first(incumbent_candidate_magar),
    incumbent_vote = first(incumbent_vote),
    # researched_incumbent = first(researched_incumbent),
    # source_researched_incumbent = first(source_researched_incumbent),
    incumbent_party_JL = first(incumbent_party_JL),
    incumbent_candidate_JL = first(incumbent_candidate_JL),
    incumbent_party_Horacio = first(incumbent_party_Horacio),
    incumbent_party_inafed = first(incumbent_party_inafed),
    incumbent_candidate_inafed = first(incumbent_candidate_inafed),
    # state_year = first(state_year),
    # state_incumbent = first(state_incumbent)
  )

#State values

db <- db %>%
  mutate(state_year = case_when(
    year == 2002 ~ 1999,
    year %in% c(2005,2008) ~ 2005,
    year == 2011 ~ 2011,
    year %in% c(2015, 2018) ~ 2015,
    TRUE ~ NA_integer_
  ),
  researched_incumbent = NA,  # Create empty variable state_incumbent
  source_researched_incumbent = NA,  # Create empty variable state_candidate
  PRI_vote = NA,
  PRI_vote_party_component = NA,
  ) %>%
  mutate(state_incumbent_party = case_when(
    state_year %in% 1999 ~ "PRI",
    state_year %in% 2005 ~ "PRD",
    state_year %in% 2011 ~ "PRD",
    state_year %in% 2015 ~ "PAN"
  )) %>%
  mutate(state_incumbent_candidate = case_when(
    state_year %in% 1999 ~ "Guillermo Mercado Romero",
    state_year %in% 2005 ~ "Leonel Cota Montaño",
    state_year %in% 2011 ~ "Narciso Agúndez Montaño",
    state_year %in% 2015 ~"Marcos Covarrubias Villaseñor"
  ))  %>%
  select(uniqueid, year, state, mun, incumbent_party_magar,incumbent_candidate_magar,incumbent_vote,researched_incumbent,source_researched_incumbent,incumbent_party_JL,incumbent_candidate_JL,incumbent_party_Horacio,incumbent_party_inafed,incumbent_candidate_inafed,state_year,state_incumbent_party,state_incumbent_candidate,PRI_vote,PRI_vote_party_component)


write_xlsx(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/bajasur/bajasur_collapsed.xlsx")



# # Keep only the specified columns in the specified order
# final_db <- collapsed_db %>%
#   select(state, mun,uniqueid, year, incumbent_party_magar, incumbent_candidate_magar, incumbent_vote, researched_incumbent, source_researched_incumbent, incumbent_party_Horacio, incumbent_party_inafed, incumbent_party_JL, state_year, state_incumbent)
# 
# # Extract the first number of uniqueid and create a new column uniqueid_group
# final_db <- final_db %>%
#   mutate(uniqueid_group = as.numeric(substring(uniqueid, 1, regexpr("[0-9]{3}$", uniqueid) - 1)))
# 
# # Calculate the total number of rows and number of rows with missing values for the variable incumbent_vote for each uniqueid grouping
# missing_counts <- final_db %>%
#   group_by(uniqueid_group) %>%
#   summarise(
#     total_rows = n(),
#     missing_rows = sum(is.na(incumbent_vote) | incumbent_vote == "")
#   )
# 
# # Save the combined data as state_combined_draft.xlsx
# write_xlsx(final_db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/collapsed_db.xlsx")
# 
# # Save the missing counts as missing_counts.xlsx
# write_xlsx(missing_counts, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/missing_counts.xlsx")


# # Create LaTeX table
# latex_table <- xtable(missing_counts, caption = "Missing Counts by UniqueID Group", label = "tab:missing_counts")
# print(latex_table, type = "latex", file = "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/missing_counts_table.tex")