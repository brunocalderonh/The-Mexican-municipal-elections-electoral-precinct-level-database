rm(list=ls())

library(stringr)
library(dplyr)
library(writexl)
library(haven)

# Load the data
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/chiapas/chiapas_updated/")

db <- read_dta("chiapas_ALL_SALVADOR.dta")
extra_correction <- read.csv("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/correct_extra_elec.csv")

extra_correction <- extra_correction %>%
  select(-X)
# db <- db %>%
#   select(uniqueid, section, year, winner, 
#          PAN, PRI, PRD, PartCardenista, PT, PVEM, PDCH, PFCPCH, PT_PFCPCH, 
#          Alianza_Justa, PC, PSN, PAS, PAC, UNKNOWN, PRD_PT_PVEM_PSN, PRD_PT, 
#          PRD_PVEM, PAN_PRD, PAN_PRD_PT, PAN_PT, PRI_PVEM, PANAL, PAN_PVEM, 
#          PRD_PT_PVEM_PC, PRD_PT_PVEM, PRD_PT_PC, PRD_PVEM_PC, PRD_PC, PT_PVEM, PT_PC, PSD, 
#          PAN_PRD_PC_PANAL, PAN_PRI_PRD_PT_PVEM_PC_PANAL, POP, PRI_PVEM_POP, PRI_POP, 
#          PVEM_POP, PAN_POP, MC, PCU, MORENA, PH, PES, MVC, PRI_PVEM_PANAL_PCU, 
#          PRI_PVEM_PANAL, PVEM_PANAL, PT_MC, CI, PAN_PRD_MC, PT_MORENA_PES, CI_19, CI_6, CI_5, 
#          CI_4, CI_3, CI_2, CI_7, CI_9, CI_10, CI_11, CI_12, CI_1, CI_13, CI_14, CI_15, CI_16, CI_17,
#          CI_18, CI_8, CI_20, CI_21, CI_22, CI_23, CI_24, CI_25, CI_26, CI_27, CI_28, CI_29, CI_30, 
#          CI_31, CI_32, CI_33, CI_34, CI_35, CI_36, CI_37, CI_38, CI_39, CI_40, CI_41)
#          
# Select and remove unwanted variables
db <- db %>%
  select(-matches("^(coalition|.*incumbent|.*winner_counter|.*STATE|.*.winner_|.*mun_|.*_winner.*|.*first.*|.*second.*|.*third.*|.*turnout.*|.*month.*)"))

# Reorder columns
db <- db %>%
  rename(mun = municipality ) %>%
  mutate(state = "CHIAPAS") %>%
  select(mun, state, uniqueid, section, year, winner, everything()) 


db <- db %>%
  anti_join(extra_correction, by = c("section","mun","year", "uniqueid"))



write_dta(db,"/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/chiapas/chiapas_vote.dta")
