# Clear the environment
rm(list = ls())

# Load necessary libraries
library(readxl)
library(writexl)
library(dplyr)
library(xtable)
library(openxlsx)

# Set working directory
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/")

# Read the Excel file
db <- read_excel("yucatan/yucatan_FINAL_draft.xlsx")

# Collapse the database
db <- db %>%
  group_by(uniqueid, year, state, mun) %>%
  summarise(
    incumbent_party_magar = first(incumbent_party_magar),
    incumbent_candidate_magar = first(incumbent_candidate_magar),
    incumbent_vote = first(incumbent_vote),
    # researched_incumbent = first(researched_incumbent),
    # source_researched_incumbent = first(source_researched_incumbent),
    incumbent_party_JL = first(incumbent_party_JL),
    incumbent_candidate_JL = first(incumbent_candidate_JL),
    incumbent_party_Horacio = first(incumbent_party_Horacio),
    incumbent_party_inafed = first(incumbent_party_inafed),
    incumbent_candidate_inafed = first(incumbent_candidate_inafed),
    # state_year = first(state_year),
    # state_incumbent = first(state_incumbent)
  )

#State values

db <- db %>%
  mutate(state_year = case_when(
    year %in% 1998 ~ 1995,
    year %in% c(2001,2004) ~ 2001,
    year %in% c(2007,2010) ~ 2007,
    year %in% c(2012,2015) ~ 2012,
    year %in% 2018 ~ 2018,   

    TRUE ~ NA_integer_
  ),
  researched_incumbent = NA,  # Create empty variable state_incumbent
  source_researched_incumbent = NA,  # Create empty variable state_candidate
  PRI_vote = NA,
  PRI_vote_party_component = NA,
  ) %>%
  mutate(state_incumbent_party = case_when(
    state_year %in% 1995 ~ "PRI",
    state_year %in% 2001 ~ "PRI",
    state_year %in% 2007 ~ "PAN",
    state_year %in% 2012 ~ "PRI",
    state_year %in% 2018 ~ "PRI",
  )) %>%
  mutate(state_incumbent_candidate = case_when(
    state_year %in% 1995 ~ "Federico Granja Ricalde",
    state_year %in% 2001 ~ "Víctor Cervera Pacheco",
    state_year %in% 2007 ~ "Patricio Patrón Laviada",
    state_year %in% 2012 ~ "Ivonne Ortega Pacheco",
    state_year %in% 2018 ~ "Rolando Zapata Bello",


  ))  %>%
  select(uniqueid, year, state, mun, incumbent_party_magar,incumbent_candidate_magar,incumbent_vote,researched_incumbent,source_researched_incumbent,incumbent_party_JL,incumbent_candidate_JL,incumbent_party_Horacio,incumbent_party_inafed,incumbent_candidate_inafed,state_year,state_incumbent_party,state_incumbent_candidate,PRI_vote,PRI_vote_party_component)


# Convert text columns to UTF-8
db <- db %>%
  mutate(across(where(is.character), ~ iconv(., from = "latin1", to = "UTF-8")))



write_xlsx(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/yucatan/yucatan_collapsed.xlsx")

# 
# # Write to CSV to check for issues
# write.csv(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/yucatan/yucatan_collapsed.csv", row.names = FALSE)
# 
# # Write to Excel using openxlsx
# write.xlsx(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/yucatan/yucatan_collapsed1.xlsx")