rm(list=ls())

library(stringr)
library(dplyr)
library(writexl)
library(haven)

# Load the data
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/baja/baja_updated/")

db <- read_dta("baja_ALL_SALVADOR.dta")

# db <- db %>%
#   select(uniqueid, section, year, winner, PAN, PRI, PRD, Partido_Cardenista, PT, PVEM, PRS, PPBC, PEBC, PAN_PVEM, PSN, PC_PAS,PRI_PT_PVEM_PEBC,PC,PAN_PANAL_PES,PRI_PVEM_PEBC, PT_PC,PAS,PRI_PVEM,PAN_PRD_PANAL_PEBC,PRI_PVEM_PES_PT,PRI_PVEM_PT_PANAL,PES,MC,MORENA,PPC,PEM,PH,CI_1,CI_2,CI_3,CI_4,PBC,PVEM_PT_TRA_MORENA)
# Select and remove unwanted variables
db <- db %>%
  select(-matches("^(coalition|.*incumbent|.*winner_counter|.*STATE|.*.winner_|.*mun_|.*_winner.*|.*first.*|.*second.*|.*third.*|.*turnout.*|.*month.*)"))

# Reorder columns
db <- db %>%
  mutate(mun = municipality ) %>%
  mutate(state = "BAJA CALIFORNIA") %>%
  select(mun, state, uniqueid, section, year, winner, everything()) 


write_dta(db,"/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/baja/baja_vote.dta")
 