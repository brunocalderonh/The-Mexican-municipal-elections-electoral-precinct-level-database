rm(list=ls())

library(stringr)
library(dplyr)
library(writexl)
library(haven)

# Load the data
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/coahuila/coahuila_updated/")

db <- read_dta("coahuila_ALL_SALVADOR.dta")

# db <- db %>%
#   select(uniqueid, section, year, winner,
#          PAN, PRI, PRD, PCC, PT, PVEM, PRT, PPS, PD, PUDC, 
#          PAN_PRD_PT_PVEM, PL, PCD, PAS, PSN, PRD_PT, PRD_PT_PCD, 
#          PRD_PT_PUDC, PRD_PT_PUDC_PCC, PRD_PUDC, PRD_PUDC_PCC_PL, 
#          PT_PCC, PUDC_PCC_PAS, PC, PAN_PUDC, PASDC, PRI_PANAL, PANAL, 
#          PSD, PRI_PVEM, PRI_PVEM_PANAL, PRI_PVEM_PSD, PRI_PVEM_PANAL_PSD,
#          PRI_PANAL_PSD, PRI_PSD, PAN_PRD_PUDC, PRD_PVEM_PSD, PRD_PSD, 
#          PT_PUDC, PVEM_PSD, PUDC_PANAL, CCM1, CCM2, UDC, PMC, PSDC, PPC, 
#          PJ, PRC, PPRO, PAN_PPRO, PAN_PRD_PT_UDC_PPRO, PAN_PRD_UDC, 
#          PAN_PRD_UDC_PPRO, PAN_PT, PAN_PT_UDC, PAN_PT_UDC_PPRO, PAN_UDC, 
#          PAN_UDC_PPRO, PRI_PANAL_PSDC_PJ_PRC, PRI_PANAL_PRC, PRI_PANAL_PSDC_PJ,
#          PRI_PANAL_PSDC_PRC, PRI_PVEM_PANAL_PJ, PRI_PVEM_PANAL_PJ_PRC, PRI_PVEM_PANAL_PRC,
#          PRI_PVEM_PANAL_PSDC, PRI_PVEM_PANAL_PSDC_PJ, PRI_PVEM_PANAL_PSDC_PJ_PRC, PT_PVEM, 
#          PMC_PSDC, PPC_PJ, PRD_PPC_PJ_PPRO, PRD_PSDC_PPC, PRD_PT_PSDC_PPC, PSDC_PPC_PJ, MC, 
#          SI, PCP, MORENA, PAN_UDC_PPC_PES, PRI_PVEM_PANAL_SI_PJ_PRC_PCP, CI_1, CI_2, CI_3, 
#          PES, PT_MORENA_PES, PAN_UDC_MC, CI_4, CI_5, CI_6, CI_7, CI_8, CI_9, CI_10
#   )

# Select and remove unwanted variables
db <- db %>%
  select(-matches("^(coalition|.*incumbent|.*winner_counter|.*STATE|.*.winner_|.*mun_|.*_winner.*|.*first.*|.*second.*|.*third.*|.*turnout.*|.*month.*)"))

# Reorder columns
db <- db %>%
  rename(mun = municipality ) %>%
  mutate(state = "COAHUILA") %>%
  select(mun, state, uniqueid, section, year, winner, everything())


write_dta(db,"/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/coahuila/coahuila_vote.dta")
