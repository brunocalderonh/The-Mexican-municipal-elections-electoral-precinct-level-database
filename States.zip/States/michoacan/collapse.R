# Clear the environment
rm(list = ls())

# Load necessary libraries
library(readxl)
library(writexl)
library(dplyr)
library(xtable)
library(openxlsx)

# Set working directory
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/")

# Read the Excel file
db <- read_excel("michoacan/michoacan_FINAL_draft.xlsx")

# Collapse the database
db <- db %>%
  group_by(uniqueid, year, state, mun) %>%
  summarise(
    incumbent_party_magar = first(incumbent_party_magar),
    incumbent_candidate_magar = first(incumbent_candidate_magar),
    incumbent_vote = first(incumbent_vote),
    # researched_incumbent = first(researched_incumbent),
    # source_researched_incumbent = first(source_researched_incumbent),
    incumbent_party_JL = first(incumbent_party_JL),
    incumbent_candidate_JL = first(incumbent_candidate_JL),
    incumbent_party_Horacio = first(incumbent_party_Horacio),
    incumbent_party_inafed = first(incumbent_party_inafed),
    incumbent_candidate_inafed = first(incumbent_candidate_inafed),
    # state_year = first(state_year),
    # state_incumbent = first(state_incumbent)
  )

#State values

db <- db %>%
  mutate(state_year = case_when(
    year %in%  c(1998,2001) ~ 1996,
    year %in% c(2004,2005,2007) ~ 2002,
    year %in%  2011 ~ 2008,
    year %in% c(2015,2018) ~ 2015,
    TRUE ~ NA_integer_
  ),
  researched_incumbent = NA,  # Create empty variable state_incumbent
  source_researched_incumbent = NA,  # Create empty variable state_candidate
  PRI_vote = NA,
  PRI_vote_party_component = NA,
  ) %>%
  mutate(state_incumbent_party = case_when(
    state_year %in% 1996 ~ "PRI",
    state_year %in% 2002 ~ "PRI",
    state_year %in% 2008 ~ "PRD",
    state_year %in% 2015 ~ "PRI",
  )) %>%
  mutate(state_incumbent_candidate = case_when(
    state_year %in% 1996 ~ "Ausencio Chávez Hernández",
    state_year %in% 2002 ~ "Víctor Manuel Tinoco Rubí",
    state_year %in% 2008 ~ "Lázaro Cárdenas Batel",
    state_year %in% 2015 ~ "Salvador Jara Guerrero",
  ))  %>%
  select(uniqueid, year, state, mun, incumbent_party_magar,incumbent_candidate_magar,incumbent_vote,researched_incumbent,source_researched_incumbent,incumbent_party_JL,incumbent_candidate_JL,incumbent_party_Horacio,incumbent_party_inafed,incumbent_candidate_inafed,state_year,state_incumbent_party,state_incumbent_candidate,PRI_vote,PRI_vote_party_component)


# Convert text columns to UTF-8
db <- db %>%
  mutate(across(where(is.character), ~ iconv(., from = "latin1", to = "UTF-8")))



write_xlsx(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/michoacan/michoacan_collapsed.xlsx")

# 
# # Write to CSV to check for issues
# write.csv(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/michoacan/michoacan_collapsed.csv", row.names = FALSE)
# 
# # Write to Excel using openxlsx
# write.xlsx(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/michoacan/michoacan_collapsed1.xlsx")