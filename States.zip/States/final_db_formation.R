# Clear the environment
rm(list = ls())
library(readxl)
library(dplyr)

# Define the base path
base_path <- "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/"

# Define the state names
states <- c("aguascalientes", "baja", "bajasur", "campeche", "chiapas", "chihuahua", 
            "coahuila", "colima", "durango", "guanajuato", "guerrero", "hidalgo", 
            "jalisco", "cdmx", "mexico", "michoacan", "morelos", "nayarit", 
            "nuevoleon", "oaxaca", "puebla", "queretaro", "quintanaroo", 
            "sanluispotosi", "sinaloa", "sonora", "tabasco", "tamaulipas", 
            "tlaxcala","veracruz", "yucatan", "zacatecas")

# Initialize an empty list to store the data frames
df_list <- list()

# Loop through each state, read the data, and append the relevant variables
for (state in states) {
  # Construct the file path with the correct naming convention
  file_path <- paste0(base_path, state, "/", state, "_FINALV.csv")
  
  # Check if the file exists before attempting to read it
  if (file.exists(file_path)) {
    # Read the CSV file
    data <- read.csv(file_path)
    
    # Select the relevant columns
    data_selected <- data %>%
      select(
        uniqueid,
        year,
        state,
        mun,
        section,
        incumbent_party_magar,
        incumbent_candidate_magar,
        incumbent_vote,
        party_component,
        mutually_exclusive,
        researched_incumbent,
        source_researched_incumbent,
        incumbent_party_JL,
        incumbent_candidate_JL,
        incumbent_party_Horacio,
        incumbent_party_inafed,
        incumbent_candidate_inafed,
        state_year,
        state_incumbent_party,
        state_incumbent_candidate,
        state_incumbent_vote,
        state_incumbent_vote_party_component,
        PRI_vote,
        PRI_vote_party_component,
        PRD_vote,
        PRD_vote_party_component,
        PAN_vote,
        PAN_vote_party_component,
        MORENA_vote,
        MORENA_vote_party_component,
        listanominal,
        valid,
        total)
    
    # Add the data to the list
    df_list[[state]] <- data_selected
  } else {
    warning(paste("File does not exist:", file_path))
  }
}

# Combine all data frames into one
final_df <- bind_rows(df_list)

# # Remove rows with empty, NA, or zero values in the incumbent_vote column
# final_df_clean <- final_df %>%
#   filter(!is.na(incumbent_vote) & incumbent_vote != 0)




write.csv(final_df, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/FINAL_db.csv")

validation <- final_df %>%
  group_by(section,year, uniqueid) %>%
  summarise(count = n())
