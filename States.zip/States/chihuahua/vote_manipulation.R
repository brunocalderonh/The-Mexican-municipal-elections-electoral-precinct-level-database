rm(list=ls())

library(stringr)
library(dplyr)
library(writexl)
library(haven)

# Load the data
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/chihuahua/chihuahua_updated/")

db <- read_dta("chihuahua_ALL_SALVADOR.dta")
extra_correction <- read.csv("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/correct_extra_elec.csv")

extra_correction <- extra_correction %>%
  select(-X)
# db <- db %>%
#   select(uniqueid, section, year, winner, PAN, PRI,PRD,PCDP,PT,PVEM,PC,PSN,
#          PAS,PAN_PRD,PRD_PT,PT_PVEM,PC_PSN,PRI_PR_PVEM_PSN,PAN_PRD_PC,PRI_PT_PVEM,
#          PRI_PVEM, PRI_PT,PRI_PANAL,PRD_PC,PRI_PVEM_PANAL,PT_PC,PAN_PT,PRI_PT_PANAL,
#          PRI_PT_PVEM_PANAL,PRI_PRD_PVEM_PANAL,PRI_PRD_PT_PANAL,PRI_PRD_PANAL_PT_PVEM,
#          PRI_PVEM_PANAL_PT,MC, MORENA,PES, CI_1,CI_2,CI_3,PANAL,PAN_MC, PT_MORENA_PES)
#          

# Select and remove unwanted variables
db <- db %>%
  select(-matches("^(coalition|.*incumbent|.*winner_counter|.*STATE|.*.winner_|.*mun_|.*_winner.*|.*first.*|.*second.*|.*third.*|.*turnout.*|.*month.*)"))

# Reorder columns
db <- db %>%
  rename(mun = municipality ) %>%
  mutate(state = "CHIHUAHUA") %>%
  select(mun, state, uniqueid, section, year, winner, everything())


db <- db %>%
  anti_join(extra_correction, by = c("section","mun","year", "uniqueid"))



write_dta(db,"/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/chihuahua/chihuahua_vote.dta")
