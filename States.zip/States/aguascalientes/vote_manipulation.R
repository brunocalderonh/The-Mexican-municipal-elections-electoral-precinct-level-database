rm(list=ls())

library(stringr)
library(dplyr)
library(writexl)
library(haven)

# Load the data
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/aguascalientes/Aguascalientes_updated/")

db <- read_dta("Aguascalientes_ALL_SALVADOR.dta")


# validation <- db %>%
#   group_by(year,uniqueid,section) %>% 
#   summarise(count = n())

# db <- db %>%
#   select(uniqueid, section, year, winner, PAN, PRI_PT_PVEM, PRD_PC, PAN_PANAL,PRI,PRD, PT, PVEM, PC,PAS,PRI_PVEM_PANAL,MC, PANAL,PAN_PRD, PRI_PVEM,MORENA,PES, PRI_PT_PANAL,CI_1,CI_2,CI_3,CI_4,UPM,PLA)
# Select and remove unwanted variables
db <- db %>%
  select(-matches("^(.*STATE|.*winner_counter|.*winner_|.*mun_|.*_winner.*|.*first.*|.*second.*|.*third.*|.*turnout.*|.*month.*)"))

# Reorder columns
db <- db %>%
  mutate(mun = municipality ) %>%
  mutate(state = "AGUASCALIENTES") %>%
  select(mun, state, uniqueid, section, year, winner, everything()) 
  


write_dta(db,"/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/aguascalientes/aguascalientes_vote.dta")
