rm(list=ls())

library(stringr)
library(dplyr)
library(writexl)
library(haven)

# Load the data
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/colima/colima_updated/")

db <- read_dta("colima_ALL_SALVADOR.dta")

# db <- db %>%
#   select(uniqueid, section, year, winner, 
#            PAN, PRI, PPS, PRD, PartCardenista, PD, PRT, PT, PVEM,PDS, ADC,
#          PAN_PRD,PC,PSN,PAS,MexicoPosible, FC,PRI_PVEM,PRD_ADC,PT_PC,PAN_ADC,
#          PRI_PANAL,PRD_PSD,MC,MORENA,PH,PES, PANAL, PRI_PVEM_PANAL,MORENA_PT_PES,
#          CI_1)

# Select and remove unwanted variables
db <- db %>%
  select(-matches("^(coalition|.*incumbent|.*winner_counter|.*STATE|.*.winner_|.*mun_|.*_winner.*|.*first.*|.*second.*|.*third.*|.*turnout.*|.*month.*)"))

# Reorder columns
db <- db %>%
  rename(mun = municipality ) %>%
  mutate(state = "COLIMA") %>%
  select(mun, state, uniqueid, section, year, winner, everything()) 


write_dta(db,"/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/colima/colima_vote.dta")
