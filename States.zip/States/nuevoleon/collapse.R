# Clear the environment
rm(list = ls())

# Load necessary libraries
library(readxl)
library(writexl)
library(dplyr)
library(xtable)
library(openxlsx)

# Set working directory
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/")

# Read the Excel file
db <- read_excel("nuevoleon/nuevoleon_FINAL_draft.xlsx")

# Collapse the database
db <- db %>%
  group_by(uniqueid, year, state, mun) %>%
  summarise(
    incumbent_party_magar = first(incumbent_party_magar),
    incumbent_candidate_magar = first(incumbent_candidate_magar),
    incumbent_vote = first(incumbent_vote),
    # researched_incumbent = first(researched_incumbent),
    # source_researched_incumbent = first(source_researched_incumbent),
    incumbent_party_JL = first(incumbent_party_JL),
    incumbent_candidate_JL = first(incumbent_candidate_JL),
    incumbent_party_Horacio = first(incumbent_party_Horacio),
    incumbent_party_inafed = first(incumbent_party_inafed),
    incumbent_candidate_inafed = first(incumbent_candidate_inafed),
    # state_year = first(state_year),
    # state_incumbent = first(state_incumbent)
  )

#State values

db <- db %>%
  mutate(state_year = case_when(
    year %in% c(2000,2003,2006) ~ 2003,
    year %in% c(2009,2012) ~ 2009,
    year %in% 2015 ~ 2015,
    year %in% 2018 ~ 2017,
    TRUE ~ NA_integer_
  ),
  researched_incumbent = NA,  # Create empty variable state_incumbent
  source_researched_incumbent = NA,  # Create empty variable state_candidate
  PRI_vote = NA,
  PRI_vote_party_component = NA,
  ) %>%
  mutate(state_incumbent_party = case_when(
    state_year %in% 2003 ~ "PAN",
    state_year %in% 2009 ~ "PRI",
    state_year %in% 2015 ~ "PRI",
    state_year %in% 2017 ~ "CI",
  )) %>%
  mutate(state_incumbent_candidate = case_when(
    state_year %in% 2003 ~ "Fernando Canales Clariond",
    state_year %in% 2009 ~ "José Natividad González Parás",
    state_year %in% 2015 ~ "Rodrigo Medina de la Cruz",
    state_year %in% 2017 ~ "Jaime Heliodoro Rodríguez Calderón",
  ))  %>%
  select(uniqueid, year, state, mun, incumbent_party_magar,incumbent_candidate_magar,incumbent_vote,researched_incumbent,source_researched_incumbent,incumbent_party_JL,incumbent_candidate_JL,incumbent_party_Horacio,incumbent_party_inafed,incumbent_candidate_inafed,state_year,state_incumbent_party,state_incumbent_candidate,PRI_vote,PRI_vote_party_component)


write_xlsx(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/nuevoleon/nuevoleon_collapsed.xlsx")

# 
# # Write to CSV to check for issues
# write.csv(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/nuevoleon/nuevoleon_collapsed.csv", row.names = FALSE)
# 
# # Write to Excel using openxlsx
# write.xlsx(db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/nuevoleon/nuevoleon_collapsed1.xlsx")