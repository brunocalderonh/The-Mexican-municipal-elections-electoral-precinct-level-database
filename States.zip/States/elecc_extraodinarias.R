# Clear the environment
rm(list = ls())
library(readxl)
library(dplyr)
library(xtable)

# Define the base path 
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/")

finaldb <- read.csv("FINAL_db.csv")

Validation <- finaldb %>% 
  dplyr::group_by(year,uniqueid,section) %>% 
  dplyr::summarise(Count = n()) %>% 
  dplyr::filter(Count > 1) %>% 
  dplyr::mutate(Validation = 1)

Validation_2 <- Validation %>% 
  dplyr::select(year,uniqueid,section,Validation)

finaldb <- dplyr::left_join(finaldb,Validation_2,
                             by = c("year"="year",
                                    "uniqueid"="uniqueid",
                                    "section"="section"))

finaldb <- finaldb %>% 
  dplyr::filter(Validation == 1) %>% 
  select(section,uniqueid,year,mun,state,Validation)


#I keep the ones I don't want and remove the ones I want to later merge and remove the matches:
finaldb <- finaldb %>% 
  filter(!(uniqueid == "7091" & year == "2015" & state == "CHIAPAS" & mun == "TAPILULA")) %>% # Normal eleccion 
  filter(!(uniqueid == "8015" & year == "2013" & state == "CHIHUAHUA" & mun == "COYAME DEL SOTOL")) %>%  # Normal eleccion
  filter(!(uniqueid == "13045" & year == "2016" & state == "HIDALGO" & mun == "Omitlán de Juárez EXTRAORDINARIO")) %>%  # Extra eleccion
  filter(!(uniqueid == "14071" & year == "2009" & state == "JALISCO" & mun == "SAN CRISTOBAL DE LA BARRANCA")) %>%  # Normal eleccion
  filter(!(uniqueid == "14079" & year == "2009" & state == "JALISCO" & mun == "JALISCO GOMEZ FARIAS")) %>%  # Normal eleccion
  filter(!(uniqueid == "15011" & year == "2003" & state == "MEXICO" & mun == "ATENCO EXTRAORDINARIO")) %>%  # Extra eleccion
  filter(!(uniqueid == "16076" & year == "2015" & state == "MICHOACAN" & mun == "SAHUAYO")) %>%  # Normal eleccion
  filter(!(uniqueid == "19039" & year == "2018" & state == "NUEVO LEON" & mun == "MONTERREY EXTRAORDINARIO")) %>%  # Extra eleccion
  filter(!(uniqueid == "20199" & year == "2018" & state == "OAXACA" & mun == "SAN JUAN IHUALTEPEC EXTRAORDINARIO")) %>%  # Extra eleccion
  filter(!(uniqueid == "29002" & year == "2013" & state == "TLAXCALA" & mun == "APETATITLAN DE ANTONIO CARVAJAL EXTRAORDINARIOO")) %>%  # Extra eleccion
  filter(!(uniqueid == "32056" & year == "2016" & state == "ZACATECAS" & mun == "ZACATECAS")) %>%   # Normal eleccion
  filter(!( state == "VERACRUZ")) 

write.csv(finaldb, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/correct_extra_elec.csv")



# #collapse 
# collapsed_db <- finaldb %>%
#   group_by(uniqueid, year, mun) %>%
#   summarise(across(everything(), first), .groups == "drop")
# 
# table_data <- collapsed_db %>%
#   select(year, section, uniqueid, mun, state)
# 
# 
# latex_table <- xtable(table_data)
# 
# write.csv(collapsed_db, "/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/extraodinarias_elec.csv")
# 
# 
