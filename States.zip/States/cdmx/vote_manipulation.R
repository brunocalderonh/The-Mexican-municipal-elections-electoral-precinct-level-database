rm(list=ls())

library(stringr)
library(dplyr)
library(writexl)
library(haven)

# Load the data
setwd("/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/cdmx/cdmx_updated/")

db <- read_dta("cdmx_ALL_SALVADOR.dta")

# db <- db %>%
#   select(uniqueid, section, year, winner, PAN_PVEM, PRI, PARM, DSPPN,
#          PRD_PT_MC_PSN_PCD_PAS,PAN,PRD,PT,PVEM,MC,PSN,PAS,MP,PLM,FC,PRI_PVEM_FC,
#          PT_MC_FC,PRI_FC,PT_FC,PRI_PVEM,PT_PVEM_MC,PAS_FC,PT_MC,MC_PAS,MC_PLM,
#          PT_MC_PAS_PLM,PRD_PT_MC,PANAL, PASC,PAN_PANAL,PSD,PRD_PT,PRD_MC,MORENA,PH,PES,CI_1,
#          CI_2,CI_3,CI_4,PRD_PT_PANAL,MORENA_PT_PES,PAN_PRD_MC)

# Select and remove unwanted variables
db <- db %>%
  select(-matches("^(coalition|.*incumbent|.*winner_counter|.*STATE|.*.winner_|.*mun_|.*_winner.*|.*first.*|.*second.*|.*third.*|.*turnout.*|.*month.*)"))

# Reorder columns
db <- db %>%
  rename(mun = municipality ) %>%
  mutate(state = "CDMX") %>%
  select(mun, state, uniqueid, section, year, winner, everything()) 


write_dta(db,"/Users/brunocalderon/Library/CloudStorage/OneDrive-Personal/Documents/ITAM/RA - Horacio/Monitoring Brokers/Data/States/cdmx/cdmx_vote.dta")
